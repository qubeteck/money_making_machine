(() => {
  const emerald = "#10b981";
  const rose = "#f43f5e";

  const fmt = (value) => {
    if (value === null || value === undefined || Number.isNaN(Number(value))) return "—";
    const n = Number(value);
    if (Math.abs(n) >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 0 });
    if (Math.abs(n) >= 10) return n.toLocaleString(undefined, { maximumFractionDigits: 1 });
    return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
  };

  const makeChart = (canvas, labels, values, options = {}) => {
    if (!canvas || !window.Chart) return null;
    const ctx = canvas.getContext("2d");
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.parentElement.clientHeight || 280);
    gradient.addColorStop(0, "rgba(16, 185, 129, 0.28)");
    gradient.addColorStop(1, "rgba(16, 185, 129, 0.00)");
    const rising = values.length < 2 || values[values.length - 1] >= values[0];
    const line = rising ? emerald : rose;
    return new Chart(canvas, {
      type: "line",
      data: {
        labels,
        datasets: [
          {
            data: values,
            borderColor: line,
            backgroundColor: gradient,
            borderWidth: 2,
            pointRadius: 0,
            pointHoverRadius: 4,
            fill: true,
            tension: 0.25,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { intersect: false, mode: "index" },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "rgba(2, 6, 23, 0.95)",
            borderColor: "rgba(51, 65, 85, 0.8)",
            borderWidth: 1,
            titleColor: "#94a3b8",
            bodyColor: "#f1f5f9",
            padding: 10,
            callbacks: {
              label: (item) => ` ${fmt(item.parsed.y)} USDT`,
            },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: "#475569", maxTicksLimit: 6, font: { size: 10 } },
            border: { display: false },
          },
          y: {
            position: "right",
            grid: { color: "rgba(51, 65, 85, 0.25)" },
            ticks: { color: "#475569", font: { size: 10 }, callback: (v) => fmt(v) },
            border: { display: false },
          },
        },
        ...options,
      },
    });
  };

  let equityChart = null;

  const loadEquity = async () => {
    const canvas = document.getElementById("equityChart");
    if (!canvas) return;
    try {
      const response = await fetch("/api/equity?limit=600", { headers: { Accept: "application/json" } });
      if (!response.ok) return;
      const data = await response.json();
      if (equityChart) {
        equityChart.data.labels = data.labels;
        equityChart.data.datasets[0].data = data.values;
        equityChart.update("none");
      } else {
        equityChart = makeChart(canvas, data.labels, data.values);
      }
    } catch (error) {
      console.warn("equity chart", error);
    }
  };

  const loadBacktest = () => {
    const canvas = document.getElementById("backtestChart");
    if (!canvas || !window.BACKTEST_CURVE) return;
    const curve = window.BACKTEST_CURVE;
    const labels = curve.map((point) => (point[0] || "").replace("T", " ").slice(5, 16));
    const values = curve.map((point) => Number(point[1]));
    makeChart(canvas, labels, values);
  };

  const boot = () => {
    loadEquity();
    loadBacktest();
    window.setInterval(loadEquity, 30000);

    document.addEventListener("submit", (event) => {
      const form = event.target;
      if (!(form instanceof HTMLFormElement)) return;
      const message = form.dataset.confirm;
      if (message && !window.confirm(message)) {
        event.preventDefault();
        return;
      }
      if (form.dataset.loading === "true") {
        const button = form.querySelector("button[type='submit']");
        if (button) {
          button.disabled = true;
          button.dataset.label = button.textContent;
          button.textContent = "Working…";
        }
      }
    });

    document.addEventListener("htmx:responseError", (event) => {
      console.error("HTMX error", event.detail);
    });

    const flash = document.getElementById("flash");
    if (flash) {
      window.setTimeout(() => {
        flash.classList.add("opacity-0", "transition-opacity", "duration-500");
        window.setTimeout(() => flash.remove(), 600);
      }, 6000);
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
