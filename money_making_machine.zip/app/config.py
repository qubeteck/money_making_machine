from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """Environment configuration. Secrets belong in .env, never in the database."""

    app_name: str = "Money Machine"
    environment: str = "development"
    log_level: str = "INFO"

    host: str = "127.0.0.1"
    port: int = 8000

    # Dashboard basic auth. Leave password empty to disable (local development only).
    dashboard_username: str = "admin"
    dashboard_password: str = ""

    # SQLite by default. Example: sqlite:///./data/money_machine.db
    database_url: str = f"sqlite:///{(BASE_DIR / 'data' / 'money_machine.db').as_posix()}"

    # Telegram. Create a bot with @BotFather, then send /id to your bot.
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # MEXC. API key needs futures trading permission. NEVER enable withdrawals.
    mexc_api_key: str = ""
    mexc_secret: str = ""
    mexc_password: str = ""

    # Live execution is disabled unless BOTH this flag and the dashboard mode are live.
    live_trading_allowed: bool = False

    scan_interval_seconds: int = 20
    market_cache_seconds: int = 15

    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


def ensure_data_dir() -> None:
    (BASE_DIR / "data").mkdir(parents=True, exist_ok=True)
