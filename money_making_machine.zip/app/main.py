from __future__ import annotations

import asyncio
import base64
import logging
import secrets
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from urllib.parse import urlsplit

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from fastapi import FastAPI, Request
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles

from app.config import BASE_DIR, get_settings
from app.db import init_db
from app.routers import api, dashboard
from app.services.engine import get_engine
from app.services.telegram_bot import TelegramService

settings = get_settings()

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("apscheduler.executors.default").setLevel(logging.WARNING)
logger = logging.getLogger("money_machine")


async def _scan_job() -> None:
    try:
        result = await asyncio.to_thread(get_engine().scan_once)
        if result.get("skipped"):
            logger.debug("Scan skipped: %s", result.get("reason"))
        else:
            logger.info(
                "Scan: evaluated=%s opened=%s closed=%s errors=%s time=%ss",
                result.get("evaluated"),
                result.get("opened"),
                result.get("closed"),
                len(result.get("errors") or []),
                result.get("seconds"),
            )
    except Exception:
        logger.exception("Scheduled scan failed")


async def _daily_report() -> None:
    await asyncio.to_thread(get_engine().send_daily_report)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    logger.info("Database ready")
    if not settings.dashboard_password and settings.host not in {"127.0.0.1", "localhost", "::1"}:
        logger.warning(
            "DASHBOARD_PASSWORD is empty while HOST=%s. Set a strong dashboard password before exposing this app.",
            settings.host,
        )

    telegram = TelegramService()
    await telegram.start()
    app.state.telegram = telegram

    scheduler = AsyncIOScheduler(timezone="UTC")
    scheduler.add_job(
        _scan_job,
        "interval",
        seconds=max(10, settings.scan_interval_seconds),
        id="scan",
        max_instances=1,
        coalesce=True,
        next_run_time=datetime.now(timezone.utc),
    )
    scheduler.add_job(
        _daily_report,
        CronTrigger(hour=23, minute=55, timezone="UTC"),
        id="daily_report",
        max_instances=1,
    )
    scheduler.start()
    app.state.scheduler = scheduler
    logger.info("Scheduler started (every %ss)", settings.scan_interval_seconds)
    logger.info("Dashboard: http://%s:%s", settings.host, settings.port)

    try:
        yield
    finally:
        logger.info("Shutting down…")
        try:
            scheduler.shutdown(wait=False)
        except Exception:
            pass
        await telegram.stop()


app = FastAPI(
    title="Money Machine",
    description="Multi-timeframe SMC / trend-following trading bot with a Telegram control plane.",
    version="0.1.0",
    lifespan=lifespan,
)

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static")


@app.middleware("http")
async def dashboard_auth(request: Request, call_next):
    env = get_settings()

    # Basic auth does not stop cross-site form posts. Browsers send Origin on
    # state-changing requests, so reject a foreign origin even when credentials
    # are cached. Missing Origin is allowed for CLI/API clients.
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        origin = request.headers.get("origin")
        if origin:
            origin_host = (urlsplit(origin).hostname or "").lower()
            request_host = (urlsplit(f"//{request.headers.get('host', '')}").hostname or "").lower()
            if not origin_host or origin_host != request_host:
                return Response("Cross-origin request blocked", status_code=403)

    if not env.dashboard_password:
        return await call_next(request)
    path = request.url.path
    if path in {"/health", "/api/health"} or path.startswith("/static/"):
        return await call_next(request)

    authorization = request.headers.get("authorization", "")
    if authorization.startswith("Basic "):
        try:
            decoded = base64.b64decode(authorization[6:]).decode("utf-8")
            username, password = decoded.split(":", 1)
        except Exception:
            username = password = ""
        if secrets.compare_digest(username, env.dashboard_username) and secrets.compare_digest(
            password, env.dashboard_password
        ):
            return await call_next(request)

    return Response(
        "Unauthorized",
        status_code=401,
        headers={"WWW-Authenticate": 'Basic realm="Money Machine"'},
    )


@app.get("/health")
async def health():
    return {"ok": True, "time": datetime.now(timezone.utc).isoformat()}


app.include_router(dashboard.router)
app.include_router(api.router)
