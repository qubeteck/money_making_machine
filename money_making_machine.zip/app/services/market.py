from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone

import httpx

from app.config import get_settings
from app.strategy.types import Candle, MEXC_INTERVALS, timeframe_seconds

logger = logging.getLogger(__name__)

MEXC_FUTURES_BASE = "https://contract.mexc.com"


def normalize_symbol(raw: str) -> str:
    """Accept BTCUSDT, BTC_USDT, BTC/USDT or BTC/USDT:USDT and return a ccxt swap symbol."""
    value = (raw or "").strip().upper().replace("_", "/").replace("-", "/")
    if not value:
        return ""
    if ":" in value:
        base, settle = value.split(":", 1)
        return f"{base}:{settle}"
    if "/" in value:
        parts = value.split("/", 1)
        base, quote = parts[0], parts[1]
        return f"{base}/{quote}:USDT"
    for quote in ("USDT", "USDC", "USD"):
        if value.endswith(quote) and len(value) > len(quote):
            base = value[: -len(quote)]
            return f"{base}/{quote}:USDT"
    return f"{value}/USDT:USDT"


def display_symbol(symbol: str) -> str:
    return symbol.split(":", 1)[0]


def contract_symbol(symbol: str) -> str:
    pair = display_symbol(normalize_symbol(symbol))
    return pair.replace("/", "_")


class MarketData:
    """MEXC public market data with ccxt primary and REST fallback."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._exchange = None
        self._cache: dict[tuple[str, str, int], tuple[float, list[Candle]]] = {}
        self._cache_ttl = get_settings().market_cache_seconds

    def _get_exchange(self):
        if self._exchange is None:
            import ccxt

            self._exchange = ccxt.mexc(
                {
                    "enableRateLimit": True,
                    "timeout": 20000,
                    "options": {
                        "defaultType": "swap",
                        "adjustForTimeDifference": True,
                    },
                }
            )
        return self._exchange

    def _fetch_ccxt(self, symbol: str, timeframe: str, limit: int) -> list[Candle]:
        exchange = self._get_exchange()
        with self._lock:
            exchange.load_markets()
            if symbol not in exchange.markets:
                raise ValueError(f"{symbol} not found in MEXC markets")
            rows = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit + 2)
        return [
            Candle(
                ts=int(row[0] // 1000),
                open=float(row[1]),
                high=float(row[2]),
                low=float(row[3]),
                close=float(row[4]),
                volume=float(row[5] or 0.0),
            )
            for row in rows
        ]

    def _fetch_rest(self, symbol: str, timeframe: str, limit: int) -> list[Candle]:
        interval = MEXC_INTERVALS.get(timeframe)
        if interval is None:
            raise ValueError(f"No MEXC interval mapping for {timeframe}")
        url = f"{MEXC_FUTURES_BASE}/api/v1/contract/kline/{contract_symbol(symbol)}"
        response = httpx.get(url, params={"interval": interval}, timeout=20.0)
        response.raise_for_status()
        payload = response.json()
        if not payload.get("success"):
            raise ValueError(f"MEXC REST error: {payload}")
        data = payload.get("data") or {}
        times = data.get("time") or []
        candles = [
            Candle(
                ts=int(times[i]),
                open=float(data["open"][i]),
                high=float(data["high"][i]),
                low=float(data["low"][i]),
                close=float(data["close"][i]),
                volume=float((data.get("vol") or [0] * len(times))[i] or 0.0),
            )
            for i in range(len(times))
        ]
        return candles[-limit:]

    def fetch_ohlcv(self, symbol: str, timeframe: str, limit: int = 300, use_cache: bool = True) -> list[Candle]:
        symbol = normalize_symbol(symbol)
        key = (symbol, timeframe, limit)
        now_mono = time.monotonic()
        if use_cache:
            cached = self._cache.get(key)
            if cached and now_mono - cached[0] < self._cache_ttl:
                return cached[1]

        try:
            candles = self._fetch_ccxt(symbol, timeframe, limit)
        except Exception as exc:
            logger.warning("ccxt fetch failed for %s %s: %s; trying REST", symbol, timeframe, exc)
            candles = self._fetch_rest(symbol, timeframe, limit)

        now_epoch = int(datetime.now(timezone.utc).timestamp())
        closed = [c for c in candles if c.ts + timeframe_seconds(timeframe) <= now_epoch]
        result = closed[-limit:]
        if not result:
            raise ValueError(f"No closed candles returned for {symbol} {timeframe}")
        self._cache[key] = (now_mono, result)
        return result

    def fetch_history(self, symbol: str, timeframe: str, days: int, max_candles: int = 30000) -> list[Candle]:
        """Paginated history for backtests. Closed candles only."""
        symbol = normalize_symbol(symbol)
        tf_sec = timeframe_seconds(timeframe)
        now_epoch = int(datetime.now(timezone.utc).timestamp())
        start = now_epoch - max(1, days) * 86400

        try:
            exchange = self._get_exchange()
            with self._lock:
                exchange.load_markets()
                if symbol not in exchange.markets:
                    raise ValueError(f"{symbol} not found in MEXC markets")
                collected: dict[int, Candle] = {}
                since_ms = start * 1000
                tf_ms = tf_sec * 1000
                for _ in range(40):
                    rows = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=since_ms, limit=1000)
                    if not rows:
                        break
                    for row in rows:
                        candle = Candle(
                            ts=int(row[0] // 1000),
                            open=float(row[1]),
                            high=float(row[2]),
                            low=float(row[3]),
                            close=float(row[4]),
                            volume=float(row[5] or 0.0),
                        )
                        collected[candle.ts] = candle
                    since_ms = int(rows[-1][0]) + tf_ms
                    if len(rows) < 1000 or since_ms >= now_epoch * 1000 or len(collected) >= max_candles:
                        break
        except Exception as exc:
            logger.warning("ccxt history failed for %s %s: %s; trying REST", symbol, timeframe, exc)
            collected = self._fetch_rest_history(symbol, timeframe, start, now_epoch, max_candles)

        expected = min(max_candles, max(1, (now_epoch - start) // tf_sec))
        if len(collected) < expected * 0.85:
            logger.info(
                "History coverage for %s %s is %s/%s candles; merging REST history",
                symbol,
                timeframe,
                len(collected),
                expected,
            )
            try:
                collected.update(self._fetch_rest_history(symbol, timeframe, start, now_epoch, max_candles))
            except Exception as exc:
                logger.warning("REST history fallback failed for %s %s: %s", symbol, timeframe, exc)

        candles = [c for ts, c in sorted(collected.items()) if ts + tf_sec <= now_epoch]
        if not candles:
            raise ValueError(f"No history returned for {symbol} {timeframe}")
        return candles

    def _fetch_rest_history(
        self, symbol: str, timeframe: str, start: int, end: int, max_candles: int
    ) -> dict[int, Candle]:
        interval = MEXC_INTERVALS.get(timeframe)
        if interval is None:
            raise ValueError(f"No MEXC interval mapping for {timeframe}")
        tf_sec = timeframe_seconds(timeframe)
        window = 2000 * tf_sec
        url = f"{MEXC_FUTURES_BASE}/api/v1/contract/kline/{contract_symbol(symbol)}"
        collected: dict[int, Candle] = {}
        cursor = start
        for _ in range(40):
            if cursor >= end or len(collected) >= max_candles:
                break
            response = httpx.get(
                url,
                params={"interval": interval, "start": cursor, "end": min(cursor + window, end)},
                timeout=30.0,
            )
            response.raise_for_status()
            payload = response.json()
            data = payload.get("data") or {}
            times = data.get("time") or []
            for i in range(len(times)):
                candle = Candle(
                    ts=int(times[i]),
                    open=float(data["open"][i]),
                    high=float(data["high"][i]),
                    low=float(data["low"][i]),
                    close=float(data["close"][i]),
                    volume=float((data.get("vol") or [0] * len(times))[i] or 0.0),
                )
                collected[candle.ts] = candle
            if not times:
                break
            cursor = max(times) + tf_sec
        return collected

    def fetch_price(self, symbol: str) -> float:
        symbol = normalize_symbol(symbol)
        try:
            exchange = self._get_exchange()
            with self._lock:
                exchange.load_markets()
                ticker = exchange.fetch_ticker(symbol)
            price = float(ticker.get("last") or 0.0)
            if price > 0:
                return price
        except Exception as exc:
            logger.warning("ccxt ticker failed for %s: %s; trying REST", symbol, exc)

        response = httpx.get(
            f"{MEXC_FUTURES_BASE}/api/v1/contract/ticker",
            params={"symbol": contract_symbol(symbol)},
            timeout=15.0,
        )
        response.raise_for_status()
        data = response.json().get("data") or {}
        price = float(data.get("lastPrice") or 0.0)
        if price <= 0:
            raise ValueError(f"Could not fetch price for {symbol}")
        return price


_market: MarketData | None = None
_market_lock = threading.Lock()


def get_market() -> MarketData:
    global _market
    with _market_lock:
        if _market is None:
            _market = MarketData()
        return _market
