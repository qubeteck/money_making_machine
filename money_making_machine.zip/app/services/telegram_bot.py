from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import select

from app.config import get_settings
from app.db import session_scope
from app.models import Signal
from app.services.engine import get_engine
from app.services.market import display_symbol, get_market, normalize_symbol
from app.services.notify import notifier
from app.services.settings import get_bot_settings

logger = logging.getLogger(__name__)


def parse_chat_ids(*values: str) -> list[int]:
    ids: list[int] = []
    for chunk in values:
        for part in (chunk or "").replace(";", ",").split(","):
            part = part.strip()
            if not part:
                continue
            try:
                ids.append(int(part))
            except ValueError:
                logger.warning("Invalid Telegram chat id: %s", part)
    return list(dict.fromkeys(ids))


class TelegramService:
    def __init__(self) -> None:
        self.bot: Bot | None = None
        self.dp: Dispatcher | None = None
        self._task: asyncio.Task | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._stopping = False

    # ------------------------------------------------------------------ lifecycle
    async def start(self) -> None:
        settings = get_settings()
        if not settings.telegram_bot_token:
            logger.warning("TELEGRAM_BOT_TOKEN is empty; Telegram bot disabled")
            return
        self.bot = Bot(token=settings.telegram_bot_token)
        self.dp = Dispatcher()
        self._register_handlers(self.dp)
        self._loop = asyncio.get_running_loop()
        notifier.bind(self.bot, self._loop, self._chat_ids())
        self._task = asyncio.create_task(self._poll(), name="telegram-polling")
        logger.info("Telegram bot started (allowed chats: %s)", self._chat_ids() or "none configured")

    async def stop(self) -> None:
        self._stopping = True
        notifier.unbind()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        if self.bot:
            await self.bot.session.close()
        logger.info("Telegram bot stopped")

    async def _poll(self) -> None:
        assert self.bot is not None and self.dp is not None
        try:
            await self.dp.start_polling(self.bot)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("Telegram polling stopped: %s", exc)

    def refresh_chat_ids(self) -> None:
        if self.bot and self._loop:
            notifier.set_chat_ids(self._chat_ids())

    # ------------------------------------------------------------------ access
    def _chat_ids(self) -> list[int]:
        db_value = ""
        try:
            with session_scope() as db:
                db_value = get_bot_settings(db).telegram_chat_id
        except Exception:
            pass
        return parse_chat_ids(get_settings().telegram_chat_id, db_value)

    def _allowed(self, chat_id: int) -> bool:
        ids = self._chat_ids()
        return bool(ids) and chat_id in ids

    async def _guard(self, message: Message) -> bool:
        if self._allowed(message.chat.id):
            return True
        await message.answer(
            "This bot is locked.\n\n"
            f"Your chat ID: {message.chat.id}\n"
            "Add it to TELEGRAM_CHAT_ID in .env (or Settings in the dashboard) and restart the bot."
        )
        return False

    async def _guard_callback(self, callback: CallbackQuery) -> bool:
        chat_id = callback.message.chat.id if callback.message else None
        if chat_id is not None and self._allowed(chat_id):
            return True
        await callback.answer("Not authorized", show_alert=True)
        return False

    # ------------------------------------------------------------------ handlers
    def _register_handlers(self, dp: Dispatcher) -> None:
        engine = get_engine()

        @dp.message(CommandStart())
        async def start(message: Message) -> None:
            if not await self._guard(message):
                return
            await message.answer(
                "Money Machine is online.\n\n"
                "Commands:\n"
                "/status — equity, PnL, positions\n"
                "/positions — open trades with SL/TP\n"
                "/signals — latest confluence signals\n"
                "/price BTC — quote a market\n"
                "/pause — stop new entries\n"
                "/resume — resume scanning\n"
                "/kill — close everything (confirmation)\n"
                "/risk 0.5 — risk per trade\n"
                "/report — performance\n"
                "/mode paper|live — execution mode\n"
                "/settings — current configuration\n"
                "/id — show this chat ID"
            )

        @dp.message(Command("help"))
        async def help_command(message: Message) -> None:
            await start(message)

        @dp.message(Command("id"))
        async def chat_id(message: Message) -> None:
            await message.answer(f"Chat ID: {message.chat.id}")

        @dp.message(Command("status"))
        async def status(message: Message) -> None:
            if not await self._guard(message):
                return
            await message.answer(await asyncio.to_thread(engine.status_text))

        @dp.message(Command("positions"))
        async def positions(message: Message) -> None:
            if not await self._guard(message):
                return
            await message.answer(await asyncio.to_thread(engine.positions_text))

        @dp.message(Command("price"))
        async def price(message: Message) -> None:
            if not await self._guard(message):
                return
            parts = (message.text or "").split()
            raw = parts[1] if len(parts) > 1 else "BTCUSDT"
            symbol = normalize_symbol(raw)

            def fetch() -> float:
                return get_market().fetch_price(symbol)

            try:
                value = await asyncio.to_thread(fetch)
                await message.answer(f"{display_symbol(symbol)}: {value:.6g}")
            except Exception as exc:
                await message.answer(f"Could not fetch {display_symbol(symbol)}: {exc}")

        @dp.message(Command("signals"))
        async def signals(message: Message) -> None:
            if not await self._guard(message):
                return

            def load() -> str:
                with session_scope() as db:
                    rows = list(
                        db.scalars(select(Signal).order_by(Signal.created_at.desc()).limit(8))
                    )
                    if not rows:
                        return "No signals recorded yet."
                    lines = []
                    for row in rows:
                        lines.append(
                            f"{row.created_at.strftime('%m-%d %H:%M')} {row.side.upper()} "
                            f"{display_symbol(row.symbol)} score {row.score:.0f} [{row.status}]\n"
                            f"  entry {row.entry:.6g} sl {row.stop:.6g} tp {row.take_profit:.6g}"
                        )
                    return "\n\n".join(lines)

            await message.answer(await asyncio.to_thread(load))

        @dp.message(Command("pause"))
        async def pause(message: Message) -> None:
            if not await self._guard(message):
                return
            await asyncio.to_thread(engine.set_paused, True)
            await message.answer("Paused. Existing positions are still managed, no new entries.")

        @dp.message(Command("resume"))
        async def resume(message: Message) -> None:
            if not await self._guard(message):
                return
            await asyncio.to_thread(engine.set_paused, False)
            await message.answer("Resumed. The scanner is active.")

        @dp.message(Command("kill"))
        async def kill(message: Message) -> None:
            if not await self._guard(message):
                return
            keyboard = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(text="YES, close everything", callback_data="kill:yes"),
                        InlineKeyboardButton(text="Cancel", callback_data="kill:no"),
                    ]
                ]
            )
            await message.answer(
                "KILL SWITCH\n\nThis closes every open position at market and pauses the bot. Continue?",
                reply_markup=keyboard,
            )

        @dp.callback_query(F.data == "kill:no")
        async def kill_no(callback: CallbackQuery) -> None:
            if not await self._guard_callback(callback):
                return
            await callback.answer("Cancelled")
            if callback.message:
                await callback.message.edit_text("Kill switch cancelled.")

        @dp.callback_query(F.data == "kill:yes")
        async def kill_yes(callback: CallbackQuery) -> None:
            if not await self._guard_callback(callback):
                return
            await callback.answer("Closing positions…")
            if callback.message:
                await callback.message.edit_text("Kill switch engaged. Closing positions at market…")
            closed = await asyncio.to_thread(engine.kill_switch)
            if callback.message:
                await callback.message.answer(
                    f"Done. {closed} position(s) closed and bot paused. Check /positions before resuming."
                )

        @dp.message(Command("risk"))
        async def risk(message: Message) -> None:
            if not await self._guard(message):
                return
            parts = (message.text or "").split()
            if len(parts) < 2:
                await message.answer("Usage: /risk 0.5  (percent of equity per trade, 0.05–5)")
                return
            try:
                value = float(parts[1])
            except ValueError:
                await message.answer("Risk must be a number, e.g. /risk 0.5")
                return
            if not 0.05 <= value <= 5:
                await message.answer("Risk must be between 0.05 and 5 percent.")
                return

            def apply() -> None:
                with session_scope() as db:
                    get_bot_settings(db).risk_pct = value

            await asyncio.to_thread(apply)
            await message.answer(f"Risk per trade set to {value:.2f}% of equity.")

        @dp.message(Command("report"))
        async def report(message: Message) -> None:
            if not await self._guard(message):
                return
            await message.answer(await asyncio.to_thread(engine.report_text, 7))

        @dp.message(Command("settings"))
        async def show_settings(message: Message) -> None:
            if not await self._guard(message):
                return

            def load() -> str:
                with session_scope() as db:
                    s = get_bot_settings(db)
                    return (
                        f"Symbols: {s.symbols}\n"
                        f"Timeframes: {s.trend_timeframe} / {s.structure_timeframe} / {s.entry_timeframe}\n"
                        f"Risk: {s.risk_pct:.2f}% | Daily stop: {s.max_daily_loss_pct:.2f}%\n"
                        f"Max positions: {s.max_open_positions} | Leverage: {s.leverage}x\n"
                        f"Min score: {s.min_score:.0f} | Session filter: {'on' if s.session_filter else 'off'}\n"
                        f"Mode: {'PAPER' if s.paper_mode else 'LIVE'} | Paused: {s.paused}\n"
                        f"Live allowed by env: {get_settings().live_trading_allowed}"
                    )

            await message.answer(await asyncio.to_thread(load))

        @dp.message(Command("mode"))
        async def mode(message: Message) -> None:
            if not await self._guard(message):
                return
            parts = (message.text or "").split()
            if len(parts) < 2 or parts[1].lower() not in {"paper", "live"}:
                await message.answer("Usage: /mode paper  or  /mode live")
                return
            requested = parts[1].lower()
            if requested == "live":
                env = get_settings()
                if not env.live_trading_allowed:
                    await message.answer(
                        "Live trading is blocked by .env.\nSet LIVE_TRADING_ALLOWED=true and add MEXC keys first."
                    )
                    return
                if not env.mexc_api_key or not env.mexc_secret:
                    await message.answer("MEXC_API_KEY / MEXC_SECRET are missing.")
                    return
                keyboard = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(text="Arm LIVE mode", callback_data="mode:live:yes"),
                            InlineKeyboardButton(text="Cancel", callback_data="mode:live:no"),
                        ]
                    ]
                )
                await message.answer(
                    "LIVE MODE\n\nReal orders will be sent to MEXC with your configured leverage. "
                    "The bot will start PAUSED. Continue?",
                    reply_markup=keyboard,
                )
                return

            def apply_paper() -> None:
                with session_scope() as db:
                    get_bot_settings(db).paper_mode = True

            await asyncio.to_thread(apply_paper)
            await message.answer("PAPER mode enabled. No real orders will be sent.")

        @dp.callback_query(F.data == "mode:live:no")
        async def mode_no(callback: CallbackQuery) -> None:
            if not await self._guard_callback(callback):
                return
            await callback.answer("Cancelled")
            if callback.message:
                await callback.message.edit_text("Live mode cancelled.")

        @dp.callback_query(F.data == "mode:live:yes")
        async def mode_yes(callback: CallbackQuery) -> None:
            if not await self._guard_callback(callback):
                return

            def apply_live() -> None:
                with session_scope() as db:
                    s = get_bot_settings(db)
                    s.paper_mode = False
                    s.paused = True
                    # Force a fresh exchange balance read before live sizing is allowed.
                    s.live_equity = None

            await asyncio.to_thread(apply_live)
            await callback.answer("LIVE armed")
            if callback.message:
                await callback.message.edit_text(
                    "LIVE mode armed and bot PAUSED.\n\n"
                    "Verify /settings, start with the smallest risk, then send /resume."
                )

    # ------------------------------------------------------------------ notify
    async def send(self, text: str) -> None:
        if not self.bot:
            return
        for chat_id in self._chat_ids():
            try:
                await self.bot.send_message(chat_id, text)
            except Exception as exc:
                logger.warning("Telegram message to %s failed: %s", chat_id, exc)
