from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models import BotSetting
from app.services.market import display_symbol, normalize_symbol


def get_bot_settings(db: Session) -> BotSetting:
    row = db.get(BotSetting, 1)
    if row is None:
        row = BotSetting(id=1)
        db.add(row)
        db.flush()
    return row


def parse_symbols(value: str) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for raw in value.replace("\n", ",").split(","):
        symbol = normalize_symbol(raw)
        if symbol and symbol not in seen:
            seen.add(symbol)
            result.append(symbol)
    return result


def symbols_text(value: str) -> str:
    return ", ".join(display_symbol(s) for s in parse_symbols(value))


def update_bot_settings(db: Session, form) -> BotSetting:
    row = get_bot_settings(db)
    row.symbols = symbols_text(form.get("symbols", row.symbols))
    row.trend_timeframe = form.get("trend_timeframe", row.trend_timeframe).strip() or row.trend_timeframe
    row.structure_timeframe = form.get("structure_timeframe", row.structure_timeframe).strip() or row.structure_timeframe
    row.entry_timeframe = form.get("entry_timeframe", row.entry_timeframe).strip() or row.entry_timeframe

    row.risk_pct = _clamp(float(form.get("risk_pct", row.risk_pct)), 0.05, 5.0)
    row.max_daily_loss_pct = _clamp(float(form.get("max_daily_loss_pct", row.max_daily_loss_pct)), 0.1, 20.0)
    row.max_open_positions = int(_clamp(float(form.get("max_open_positions", row.max_open_positions)), 1, 10))
    row.min_score = _clamp(float(form.get("min_score", row.min_score)), 0.0, 100.0)
    row.leverage = int(_clamp(float(form.get("leverage", row.leverage)), 1, 50))
    row.starting_balance = _clamp(float(form.get("starting_balance", row.starting_balance)), 10.0, 10_000_000.0)
    row.taker_fee_pct = _clamp(float(form.get("taker_fee_pct", row.taker_fee_pct)), 0.0, 1.0)
    row.slippage_pct = _clamp(float(form.get("slippage_pct", row.slippage_pct)), 0.0, 1.0)

    row.session_filter = form.get("session_filter") == "on"
    row.session_start_utc = int(_clamp(float(form.get("session_start_utc", row.session_start_utc)), 0, 23))
    row.session_end_utc = int(_clamp(float(form.get("session_end_utc", row.session_end_utc)), 0, 23))
    row.telegram_chat_id = form.get("telegram_chat_id", row.telegram_chat_id).strip()
    row.updated_at = datetime.now(timezone.utc)
    return row


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))
