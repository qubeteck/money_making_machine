from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from urllib.parse import quote_plus

from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import select

from app.db import session_scope
from app.models import ScanResult, Trade
from app.services.analytics import day_start, performance
from app.services.engine import get_engine
from app.services.market import display_symbol, get_market, normalize_symbol
from app.services.notify import notifier
from app.services.settings import get_bot_settings, parse_symbols, update_bot_settings
from app.services.telegram_bot import parse_chat_ids
from app.strategy.backtest import run_backtest
from app.web import base_context, latest_scan_map, log_rows, signal_rows, templates

router = APIRouter()

VALID_TIMEFRAMES = {"1m", "5m", "15m", "30m", "1h", "4h", "8h", "1d"}


def _render(request: Request, name: str, context: dict):
    return templates.TemplateResponse(request=request, name=name, context=context)


def _redirect(path: str, message: str, level: str = "info") -> RedirectResponse:
    separator = "&" if "?" in path else "?"
    return RedirectResponse(
        url=f"{path}{separator}msg={quote_plus(message)}&level={level}",
        status_code=303,
    )


def _trade_rows(db, filters: dict) -> list[dict]:
    stmt = select(Trade).order_by(Trade.opened_at.desc()).limit(300)
    if filters.get("status") in {"open", "closed"}:
        stmt = stmt.where(Trade.status == filters["status"])
    if filters.get("mode") in {"paper", "live"}:
        stmt = stmt.where(Trade.mode == filters["mode"])
    if filters.get("symbol"):
        stmt = stmt.where(Trade.symbol == normalize_symbol(filters["symbol"]))
    trades = list(db.scalars(stmt))
    scans = latest_scan_map(db)
    prices = {symbol: scan.price for symbol, scan in scans.items()}
    rows = []
    for trade in trades:
        price = prices.get(trade.symbol, trade.entry)
        direction = 1 if trade.side == "long" else -1
        upnl = (price - trade.entry) * trade.qty * direction if trade.status == "open" else 0.0
        rows.append({"trade": trade, "price": price, "upnl": upnl})
    return rows


@router.get("/")
async def overview(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
        context["signal_rows"] = signal_rows(db, 8)
        context["scan_history"] = list(
            db.scalars(select(ScanResult).order_by(ScanResult.created_at.desc()).limit(30))
        )
        context["logs"] = log_rows(db, 8)
    return _render(request, "overview.html", context)


@router.get("/partials/stats")
async def stats_partial(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
    return _render(request, "partials/stats.html", context)


@router.get("/partials/positions")
async def positions_partial(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
    return _render(request, "partials/positions.html", context)


@router.get("/partials/signals")
async def signals_partial(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
        context["signal_rows"] = signal_rows(db, 6)
    return _render(request, "partials/signals.html", context)


@router.get("/partials/scanner")
async def scanner_partial(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
    return _render(request, "partials/scanner.html", context)


@router.get("/trades")
async def trades(request: Request):
    filters = {
        "status": request.query_params.get("status", ""),
        "mode": request.query_params.get("mode", ""),
        "symbol": request.query_params.get("symbol", ""),
    }
    with session_scope() as db:
        context = base_context(request, db)
        context["trade_rows"] = _trade_rows(db, filters)
        context["filters"] = filters
        context["today_stats"] = performance(db, context["settings"].starting_balance, since=day_start())
    return _render(request, "trades.html", context)


@router.get("/signals")
async def signals(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
        context["signal_rows"] = signal_rows(db, 50)
        context["scan_history"] = list(
            db.scalars(select(ScanResult).order_by(ScanResult.created_at.desc()).limit(60))
        )
        context["logs"] = log_rows(db, 20)
    return _render(request, "signals.html", context)


@router.get("/backtest")
async def backtest_page(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
    settings = context["settings"]
    first_symbol = parse_symbols(settings.symbols)[0] if parse_symbols(settings.symbols) else "BTC/USDT:USDT"
    context.update(
        {
            "form": {
                "symbol": display_symbol(first_symbol),
                "days": 90,
                "starting_balance": settings.starting_balance,
                "risk_pct": settings.risk_pct,
                "min_score": settings.min_score,
                "leverage": settings.leverage,
                "fee_pct": settings.taker_fee_pct,
                "slippage_pct": settings.slippage_pct,
            },
            "result": None,
            "error": None,
        }
    )
    return _render(request, "backtest.html", context)


@router.post("/backtest")
async def backtest_run(request: Request):
    form = await request.form()
    days = max(5, min(180, int(float(form.get("days", 90)))))
    symbol = normalize_symbol(str(form.get("symbol", "BTC/USDT")))
    starting_balance = max(10.0, float(form.get("starting_balance", 1000)))
    risk_pct = max(0.05, min(5.0, float(form.get("risk_pct", 0.5))))
    min_score = max(0.0, min(100.0, float(form.get("min_score", 70))))
    leverage = max(1, min(50, int(float(form.get("leverage", 3)))))
    fee_pct = max(0.0, min(1.0, float(form.get("fee_pct", 0.05))))
    slippage_pct = max(0.0, min(1.0, float(form.get("slippage_pct", 0.02))))
    form_values = {
        "symbol": display_symbol(symbol),
        "days": days,
        "starting_balance": starting_balance,
        "risk_pct": risk_pct,
        "min_score": min_score,
        "leverage": leverage,
        "fee_pct": fee_pct,
        "slippage_pct": slippage_pct,
    }

    with session_scope() as db:
        context = base_context(request, db)
    context.update({"form": form_values, "result": None, "error": None})

    def _run():
        market = get_market()
        entry = market.fetch_history(symbol, "15m", days)
        structure = market.fetch_history(symbol, "1h", days + 10)
        trend = market.fetch_history(symbol, "4h", days + 45)
        return run_backtest(
            symbol,
            entry,
            structure,
            trend,
            starting_balance=starting_balance,
            risk_pct=risk_pct,
            leverage=leverage,
            min_score=min_score,
            fee_pct=fee_pct,
            slippage_pct=slippage_pct,
        )

    try:
        result = await asyncio.to_thread(_run)
        context["result"] = result
        context["curve_json"] = json.dumps(result.curve)
    except Exception as exc:
        context["error"] = str(exc)
    return _render(request, "backtest.html", context)


@router.get("/settings")
async def settings_page(request: Request):
    with session_scope() as db:
        context = base_context(request, db)
    return _render(request, "settings.html", context)


@router.post("/settings")
async def settings_save(request: Request):
    form = await request.form()
    for field in ("trend_timeframe", "structure_timeframe", "entry_timeframe"):
        if str(form.get(field, "")) not in VALID_TIMEFRAMES:
            return _redirect("/settings", f"Invalid timeframe for {field}", "error")
    try:
        with session_scope() as db:
            row = update_bot_settings(db, form)
            chat_ids = parse_chat_ids(get_settings_value("telegram_chat_id"), row.telegram_chat_id)
    except Exception as exc:
        return _redirect("/settings", f"Could not save settings: {exc}", "error")
    if notifier.ready:
        notifier.set_chat_ids(chat_ids)
    return _redirect("/settings", "Settings saved")


def get_settings_value(name: str) -> str:
    from app.config import get_settings

    return str(getattr(get_settings(), name, "") or "")


@router.post("/actions/pause")
async def pause():
    get_engine().set_paused(True)
    return _redirect("/", "Bot paused. Existing positions are still managed.")


@router.post("/actions/resume")
async def resume():
    get_engine().set_paused(False)
    return _redirect("/", "Bot resumed. Scanning for setups.")


@router.post("/actions/kill")
async def kill():
    closed = await asyncio.to_thread(get_engine().kill_switch)
    return _redirect(
        "/",
        f"Kill switch engaged. {closed} position(s) closed, bot paused. Check the positions table.",
        "error",
    )


@router.post("/actions/close/{trade_id}")
async def close_trade(trade_id: int):
    closed = await asyncio.to_thread(get_engine().close_trade_by_id, trade_id)
    if not closed:
        return _redirect("/", f"Trade #{trade_id} was not open", "error")
    return _redirect("/", f"Trade #{trade_id} closed at market")


@router.post("/actions/scan")
async def scan_now():
    result = await asyncio.to_thread(get_engine().scan_once, True)
    if result.get("skipped"):
        return _redirect("/", f"Scan skipped: {result.get('reason')}", "error")
    message = (
        f"Scan complete in {result.get('seconds', 0)}s — "
        f"{result.get('evaluated', 0)} evaluated, {result.get('opened', 0)} opened, "
        f"{result.get('closed', 0)} closed"
    )
    level = "error" if result.get("errors") else "info"
    return _redirect("/", message, level)


@router.post("/actions/mode/paper")
async def mode_paper():
    with session_scope() as db:
        get_bot_settings(db).paper_mode = True
    return _redirect("/settings", "Paper mode enabled. No real orders will be sent.")


@router.post("/actions/mode/live")
async def mode_live():
    from app.config import get_settings

    env = get_settings()
    if not env.live_trading_allowed:
        return _redirect("/settings", "Live mode blocked: set LIVE_TRADING_ALLOWED=true in .env first.", "error")
    if not env.mexc_api_key or not env.mexc_secret:
        return _redirect("/settings", "Live mode blocked: MEXC API keys are missing.", "error")
    with session_scope() as db:
        row = get_bot_settings(db)
        row.paper_mode = False
        row.paused = True
        # Force a fresh exchange balance read before live sizing is allowed.
        row.live_equity = None
    return _redirect(
        "/settings",
        "LIVE mode armed and bot paused. Verify settings, then resume from the dashboard.",
        "error",
    )
